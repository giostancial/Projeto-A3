package com.mycompany.farmacia;

public class Produto {
    private String nome;
    private int valor;
    private 
}
